
const express = require("express");
const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(express.static("public"));
app.use("/downloads", express.static("server/downloads"));
app.use(express.json());

app.post("/api/download", (req, res) => {
  const { url, format } = req.body;
  const filename = `output.${format}`;
  const outputPath = path.join(__dirname, "downloads", filename);
  if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);

  const ytdlp = spawn("yt-dlp", [
    url,
    "-f", format === "mp3" ? "bestaudio" : "bestvideo+bestaudio",
    "-o", outputPath,
    "--ffmpeg-location", "/opt/homebrew/bin/ffmpeg",
    ...(format === "mp3" ? ["--extract-audio", "--audio-format", "mp3"] : [])
  ]);

  ytdlp.stderr.on("data", data => console.error(`stderr: ${data}`));
  ytdlp.on("close", code => {
    if (code === 0 && fs.existsSync(outputPath)) {
      res.json({ success: true, file: filename });
    } else {
      res.json({ success: false, error: "Download failed. Check the URL or format." });
    }
  });
});

app.listen(3000, () => console.log("Server running at http://localhost:3000"));
